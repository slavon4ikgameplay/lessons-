class CustomError(Exception):
    pass